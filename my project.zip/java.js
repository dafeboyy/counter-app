// initiate the count as 0
// listen for clicks on the increment button
// increment the count variable when the button is clicked
// change the count in the HTML to reflect the new count let
let countEl = document.getElementById("count-el")
let saveEl = document.getElementById("save-el")

let count = 0

function increment() {
    count += 1
    countEl.innerText = count
}
// 1. Create a function, save(), which logs out the count when it is 
function save() {
    let countStr = count + " - "
    saveEl.textContent += countStr 
    countEl.innerText = 0
    count = 0
    console.log(count)
}
